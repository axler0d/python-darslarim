class Restoran:
    def __init__(self, nomi, turi):
        self.nomi = nomi
        self.turi = turi
       # self.ism = "Restoran nomi: " + self.nomi + ", Restoran turi: " + self.turi

    def get_info(self):
        return f"{self.nomi} - {self.turi}"
    def set_name(self, nomi):
        self.nomi = nomi
    def set_type(self, turi):
        self.turi = turi
restoran1 = Restoran("Pizza Hut", "Fast Food")
restoran2 = Restoran("KFC", "Fast Food")
restoran3 = Restoran("Sushi Master", "Yapon taomlari")
restoranlar = [restoran1,restoran2,restoran3]
print("Restoranlar ro'yxati: ")
for restoran in restoranlar:
    print(restoran.get_info())