class Talaba:
    def __init__(self, ism, familiya, yosh):
        self.ism = ism
        self.familiya = familiya
        self.yosh = yosh
    def get_age(self):
        return self.yosh
    
    def get_surname(self):
        return self.familiya
    
    def get_name(self):
        return self.ism
    
    def birtday(self):
        self.yosh += 1
        print(f"{self.ism} {self.familiya}ning tug'ilgan kuni muborak! Yoshi: {self.yosh}")


talaba1 = Talaba("Ali", "Valiyev", 20)
talaba2 = Talaba("Vali", "Aliyev", 21)
talaba3 = Talaba("Hasan", "Husanov", 19)
talabalar = [talaba1, talaba2, talaba3]
print("Talabalar ro'yxati:")
for talaba in talabalar:
   print(talaba.get_age())
