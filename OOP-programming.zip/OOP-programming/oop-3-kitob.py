class Kitob:
    def __init__(self, nomi, muallif, yil):
        self.nomi = nomi
        self.muallif = muallif
        self.yil = yil

    def get_info(self):
        return f"{self.nomi} - {self.muallif} ({self.yil})"
kitob1 = Kitob("Alkimyogar", "Paulo Koeljo", 1988)
kitob2 = Kitob("1984", "Jorj Oruell", 1949)
kitob3 = Kitob("To'liq ishonch", "Stiven King", 1996)
kitoblar = [kitob1, kitob2, kitob3] 
print("Kitoblar ro'yxati:")
for kitob in kitoblar:
    print(kitob.get_info())
