class cars:
    def __init__(self,model,rang,yil):
        self.model = model
        self.rang = rang
        self.yil = yil
    def get_info(self):
        return f"{self.model} {self.rang}, {self.yil} yil"
car1 = cars("BMW","Qora",2020)
car2 = cars("Mercedes","Oq",2021)
car3 = cars("Audi","Qizil",2019)
avtomobillar = [car1,car2,car3]
mashina = input("Qaysi avtomobilni tanlaysiz?  =  ")
for car in avtomobillar:
    if car.model.lower() == mashina.lower():
        print(car.get_info())
        break
else:
    print("Bunday avtomobil mavjud emas.")
        