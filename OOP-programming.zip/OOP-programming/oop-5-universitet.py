class Universitet:
    def __init__(self,nom,manzil,talabalar_soni=0):
        self.nom = nom
        self.manzil = manzil
        self.talabalar_soni = talabalar_soni
    def get_info(self):
        return f"{self.nom} {self.manzil}, {self.talabalar_soni} ta talabalar"
    def get_students(self):
        return self.talabalar_soni
universitet1 = Universitet("Toshkent Davlat Universiteti","Toshkent",20000)
universitet2 = Universitet("Inha Universiteti","Toshkent",5000)
universitet3 = Universitet("Amity Universiteti","Toshkent") 
universitetlar = [universitet1,universitet2,universitet3]
print("Universitetlar ro'yxati:")
for universitet in universitetlar:
    print(universitet.get_info())
    print(f"Talabalar soni: {universitet.get_students()}")


