class BankAccount:
    def __init__(self, account_number, account_holder, balance=0):
        self.account_number = account_number
        self.account_holder = account_holder
        self.balance = balance

    def deposit(self, amount):
        if amount > 0:
            self.balance += amount
            print(f"{amount} summa depozit qilindi. Keyingi balans:  {self.balance}.")
        else:
            print("Deposit amount must be positive.")

    def withdraw(self, amount):
        if 0 < amount <= self.balance:
            self.balance -= amount
            print(f"{amount} summa yechib olindi. Keyingi balans:  {self.balance}.")
        else:
            print("Qolgan mablag' yetarli emas. Yechib olish uchun mablag' yetarli emas yoki noto'g'ri miqdor kiritildi.")

    def get_balance(self):
        return self.balance

# Example usage:
account1 = BankAccount("123456789", "Ali Valiyev", 1000)
account1.deposit(500)
account1.withdraw(200)